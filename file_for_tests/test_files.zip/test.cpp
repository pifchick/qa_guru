#include <iostream>
int main() { std::cout << "This is a C++ file" << std::endl; return 0; }