#!/bin/bash
echo "This is a shell script"